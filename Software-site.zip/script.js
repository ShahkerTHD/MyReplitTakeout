function nav() {
	document.getElementById("menu-icon").classList.toggle("menu-icon-open");
	document.getElementById("close-icon").classList.toggle("close-icon-open");

	document.getElementById("nav").classList.toggle("open");
	
}